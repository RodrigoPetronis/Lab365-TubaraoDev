package com.senai.Petronis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetronisApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetronisApplication.class, args);
	}

}
